__version__ = "1.1.7"
from .main import MetaAI  # noqa
