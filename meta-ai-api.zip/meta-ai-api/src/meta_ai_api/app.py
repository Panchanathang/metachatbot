from flask import Flask, request, jsonify
from flask_cors import CORS
from meta_ai_api.main import MetaAI
import logging

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Set up logging
logging.basicConfig(level=logging.DEBUG)

ai = MetaAI()

@app.route('/', methods=['GET'])
def index():
    return 'Welcome to my chatbot API!'

@app.route('/endpoint', methods=['POST'])
def handle_chatbot_request():
    try:
        # Log incoming request data
        logging.debug(f"Incoming request data: {request.data}")
        
        message = request.json.get('message')
        
        if not message:
            raise ValueError("No message provided in the request")
        
        response = ai.prompt(message)
        
        # Log the response from the AI correctly
        logging.debug(f"Response from MetaAI: {response}")
        
        return jsonify({'response': response})
    except Exception as error:
        # Log the error with traceback
        logging.error("An error occurred while processing the request", exc_info=True)
        
        # Return a JSON-formatted error message
        return jsonify({'error': str(error)}), 500

if __name__ == '__main__':
    app.run(debug=True)